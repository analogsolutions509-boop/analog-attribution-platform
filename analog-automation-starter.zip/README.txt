Analog Solutions - API and Collector Health Monitor

This n8n workflow is prepared for import. It is intentionally inactive until it has been imported, reviewed, and manually activated.

What it checks every 15 minutes:
- The Analog Attribution Platform health endpoint responds.
- The live collector JavaScript for derbyreinforcementsteel.com is served.
- The deployed collector contains the page-view promise and waits for that promise before requesting a dynamic tracking number.

Important:
- This checks the collector delivery and release ordering. It does NOT confirm that a site's tracking number, forwarding number, destination supplier, carrier telephony, or supplier outcome workflow is configured correctly.
- Workflow failures are recorded in n8n execution history. An email/Slack alert needs a separately configured notification credential or error workflow.
- The workflow is inactive in the JSON. Review it in the n8n editor, test it manually, then activate it.

Import:
1. Sign in to https://analog-workflows.up.railway.app
2. In n8n, use the workflow menu to import from a file.
3. Select analog-collector-health-monitor.json.
4. Run a manual test and verify the output has status=ok and all checks true.
5. Activate the workflow.
